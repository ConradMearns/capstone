-- Author:conrad
-- Name:TestScript
-- Description:
-- Icon:
-- Hide: no


--[[
TestScript = {};

function TestScript:new(customMt)
	addConsoleCommand("test", "Play with arguements", "testCommand", self);
	return self
end;


function TestScript:testCommand(args)
	if args ~= nil then
		print("Hello world!")
		return "args are "..args;
	end;
	return "Error: no arguments specified. Usage: test args";
end;
--]]


function setName(args)
	print(type(args))
	if args ~= nil then
		print("aha!")
		return "Changed name to "..args;
	end;
	print("are u winning son?");
	return "Error: no arguments specified. Usage: setName newName\n"..args;
end;



function hello()
	return "hello :0";
end;



function printArg(args)
	return "ARGS: "..args;
end;

addConsoleCommand("setName", "Changes the name", "setName", nil);
addConsoleCommand("hello", "Prints a test message", "hello", nil);
addConsoleCommand("printArg", "Prints args", "printArg", nil);

